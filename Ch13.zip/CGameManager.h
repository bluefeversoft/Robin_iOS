//
//  CGameManager.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 11/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CGameManager : NSObject

+(CGameManager*)sharedGameManager;

@property (atomic) float iPhoneFivePointOffSet;
@property (atomic) float YScaleFactor;
@property (atomic) float XScaleFactor;

-(void)SetScaleFactors;

-(void)LoadEffects;
-(void)PlayEffect:(int)EffectNum;
-(void)PlayBGMusic;

@end
