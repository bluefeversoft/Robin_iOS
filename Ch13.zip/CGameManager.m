//
//  CGameManager.m
//  Simple Flappy Robin
//
//  Created by ScreenCast on 11/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CGameManager.h"
#import "cocos2d.h"
#import "Constants.h"

@implementation CGameManager

static CGameManager* _sharedGameManager = nil;

+(CGameManager*)sharedGameManager
{
    @synchronized([CGameManager class])
    {
	if(!_sharedGameManager)
		[[self alloc] init];
	return _sharedGameManager;
    }
    return nil;
}

+(id)alloc
{
    @synchronized ([CGameManager class])
    {
	NSAssert(_sharedGameManager == nil,
			 @"Attempted to allocated a second instance of the _sharedCGameStatus singleton");
	_sharedGameManager = [super alloc];
	return _sharedGameManager;
    }
    return nil;
}

-(id)init
{
	if( (self=[super init]) ) {
	//Init in here
	}
	return self;
}

-(void)SetScaleFactors {
	self.XScaleFactor = 1.0;
	self.YScaleFactor = 1.0;
	self.iPhoneFivePointOffSet = 0.0;
	
	CGSize screenSize = [CCDirector sharedDirector].viewSize;
	
	if(UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPhone) {
		self.YScaleFactor = screenSize.height / 320 ;
	}
	
	if(screenSize.width == 568) {
		self.iPhoneFivePointOffSet = 44;
		self.XScaleFactor = screenSize.width / 480;
	}
}

-(void)LoadEffects {
	[[OALSimpleAudio sharedInstance] preloadEffect:@"Explosion1.wav"];
	[[OALSimpleAudio sharedInstance] preloadEffect:@"Explosion2.wav"];
	[[OALSimpleAudio sharedInstance] preloadEffect:@"RobinTap1.wav"];
	[[OALSimpleAudio sharedInstance] preloadEffect:@"Success1.wav"];
	[[OALSimpleAudio sharedInstance] preloadEffect:@"Success2.wav"];
	[[OALSimpleAudio sharedInstance] preloadBg:@"BGMusic.mp3"];
}

-(void)PlayEffect:(int)EffectNum {
	if(EffectNum == kEffectTap) {
		[self playEffectWithTotal:1 andName:@"RobinTap"];
	} else if(EffectNum == kEffectExplode) {
		[self playEffectWithTotal:2 andName:@"Explosion"];
	} else if(EffectNum == kEffectScore) {
		[self playEffectWithTotal:2 andName:@"Success"];
	}
}

-(void)playEffectWithTotal:(int)num andName:(NSString*)name {
	int nume = arc4random() % num + 1;
	
	NSString *fileName = [NSString stringWithFormat:@"%@%d.wav",name,nume];
	[[OALSimpleAudio sharedInstance] playEffect:fileName];
}

-(void)PlayBGMusic {
	[[OALSimpleAudio sharedInstance] playBg:@"BGMusic.mp3" loop:YES];
}




































@end
