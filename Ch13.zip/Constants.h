//
//  Constants.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 09/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#ifndef Simple_Flappy_Robin_Constants_h
#define Simple_Flappy_Robin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40
#define kZindexTree 50
#define kZindexMount 30
#define kZindexCloudSlow 10
#define kZindexCloudFast 20
#define kZindexTube 35

#define YSCALEFACTOR ([CGameManager sharedGameManager].YScaleFactor)
#define XSCALEFACTOR ([CGameManager sharedGameManager].XScaleFactor)
#define IPHONEOFFSET ([CGameManager sharedGameManager].iPhoneFivePointOffSet)

#define GRAVITY -310 * YSCALEFACTOR

#define kZindexRobin 100
#define kRobinStateStopped 0
#define kRobinStateMoving 1
#define kRobinStartSpeed 150 * YSCALEFACTOR
#define kRobinStartX 0.3

#define kCloudSpeedSlow 7.0 * YSCALEFACTOR
#define kCloudSpeedFast 25.0 * YSCALEFACTOR
#define kCloudSpeedMount 15.0 * YSCALEFACTOR
#define kCloudSpeedTree 30.0 * YSCALEFACTOR

#define kCloudScaleSlow 0.4
#define kCloudScaleFast 0.8
#define kTreeScale 1.0
#define kMountScale 0.8

#define kTubeStateActive 0
#define kTubeStateInActive 1

#define kTubeSpawnMinTime 2.3
#define kTubeSpawnTimeVariance 8

#define kSingleGapTop 220 * YSCALEFACTOR
#define kSingleGapBottom 115 * YSCALEFACTOR
#define kSingleGapMax 140 * YSCALEFACTOR
#define kSingleGapMin 80 * YSCALEFACTOR

#define kDoubleGapTop 240 * YSCALEFACTOR
#define kDoubleGapBottom 60 * YSCALEFACTOR
#define kDoubleGapMax 110 * YSCALEFACTOR
#define kDoubleGapMin 70 * YSCALEFACTOR

#define kTubeScore 1

#define kTubeTypeUpper 0
#define kTubeTypeLower 1
#define kTubeTypePair 2
#define kTubeTypeNone 3

#define kTubeMaxUpPixels 180 * YSCALEFACTOR

#define kEffectTap 0
#define kEffectExplode 1
#define kEffectScore 2


#endif



























