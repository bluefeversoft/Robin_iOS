//
//  AppDelegate.h
//  BaseStarter
//
//  Created by ScreenCast on 09/04/14.
//  Copyright BlueFever 2014. All rights reserved.
//
// -----------------------------------------------------------------------

#import "cocos2d.h"

@interface AppDelegate : CCAppDelegate
@end
