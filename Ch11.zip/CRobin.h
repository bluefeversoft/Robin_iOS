//
//  CRobin.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 11/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CCSprite.h"

@interface CRobin : CCSprite {
	float _speedY;
	float _topOfScreen;
}

@property (nonatomic) int State;

-(void)Reset;
-(void)SetStartSpeed;
-(void)Initialise:(float)tos;
-(void)UpdateRobin:(float)dt;

//added Ch11
-(CGRect)TubeCollisionBox;

@end
