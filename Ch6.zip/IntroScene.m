//
//  IntroScene.m
//  BaseStarter
//
//  Created by ScreenCast on 09/04/14.
//  Copyright BlueFever 2014. All rights reserved.
//
// -----------------------------------------------------------------------

// Import the interfaces
#import "IntroScene.h"
#import "Constants.h"
#import "CGameManager.h"
#import "CRobin.h"

// -----------------------------------------------------------------------
#pragma mark - IntroScene
// -----------------------------------------------------------------------

@implementation IntroScene {
	CRobin *_robin;
	float _floorY;
	BOOL _gameStarted;
	float _gameTime;
}

// -----------------------------------------------------------------------
#pragma mark - Create & Destroy
// -----------------------------------------------------------------------

+ (IntroScene *)scene
{
	return [[self alloc] init];
}

// -----------------------------------------------------------------------

- (id)init
{
    // Apple recommend assigning self with supers return value
    self = [super init];
    if (!self) return(nil);
	
	[[CGameManager sharedGameManager] SetScaleFactors];
	
	CCLOG(@"XScale:%.1f YScale:%.1f IphoneOffset:%.1f",
		  XSCALEFACTOR,
		  YSCALEFACTOR,
		  IPHONEOFFSET);
	
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];

	CCSprite *bgSprite = [CCSprite spriteWithImageNamed:@"MainBG.png"];
	bgSprite.positionType = CCPositionTypeNormalized;
	bgSprite.position = ccp(0.5,0.5);
	bgSprite.scaleX = XSCALEFACTOR;
	[self addChild:bgSprite z:kZindexBG];
	
	CCSprite *floorSprite = [CCSprite spriteWithImageNamed:@"Floor.png"];
	floorSprite.positionType = CCPositionTypeNormalized;
	floorSprite.position = ccp(0.5,0.0);
	floorSprite.anchorPoint = ccp(0.5, 0.0);
	floorSprite.scaleX = XSCALEFACTOR;
	[self addChild:floorSprite z:kZindexFloor];
	_floorY = floorSprite.boundingBox.size.height / 2;
	
	_robin = [CRobin spriteWithImageNamed:@"Robin.png"];
	_robin.positionType = CCPositionTypePoints;
	_robin.position = ccp(kRobinStartX * screenSize.width, 0.5 * screenSize.height);
	[self addChild:_robin z:kZindexRobin];
	[_robin Initialise:screenSize.height];
	
	CCLOG(@"Robin Box:%@ Position:%@",NSStringFromCGRect( [_robin boundingBox]),
		  NSStringFromCGPoint(_robin.position));
	_gameTime = 0.0;
	_gameStarted = NO;
	
	self.userInteractionEnabled = YES;
	
    // done
	return self;
}

-(void)update:(CCTime)delta {
	_gameTime += delta;
	//CCLOG(@"TotalTime:%.2f delta:%.3f",_gameTime,delta);
}

-(void)touchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
	CGPoint touchLocation = [touch locationInNode:self];
	CCLOG(@"touchLocation:%@",NSStringFromCGPoint(touchLocation));
}


















@end













