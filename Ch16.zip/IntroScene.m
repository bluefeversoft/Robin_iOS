//
//  IntroScene.m
//  BaseStarter
//
//  Created by ScreenCast on 09/04/14.
//  Copyright BlueFever 2014. All rights reserved.
//
// -----------------------------------------------------------------------

// Import the interfaces
#import "IntroScene.h"
#import "Constants.h"
#import "CGameManager.h"
#import "CRobin.h"
#import "CCloud.h"
#import "CTube.h"

// -----------------------------------------------------------------------
#pragma mark - IntroScene
// -----------------------------------------------------------------------

@implementation IntroScene {
	CRobin *_robin;
	float _floorY;
	BOOL _gameStarted;
	float _gameTime;
	NSMutableArray *_flyingObjects;
	NSMutableArray *_tubeObjects;
	float _nextSpawnTime;
	float _lastSpawnTime;
	int _lastTubeType;
	float _middleY;
	float _lastGetUnderY;
	CCLabelTTF *_scoreLabel;
	int _gameScore;
	CCLabelTTF *_gameOverLabel;
	CCLabelTTF *_PressToStartLabel;
	CCLabelTTF *_highScoreLabel;
}

// -----------------------------------------------------------------------
#pragma mark - Create & Destroy
// -----------------------------------------------------------------------

+ (IntroScene *)scene
{
	return [[self alloc] init];
}

// -----------------------------------------------------------------------

- (id)init
{
    // Apple recommend assigning self with supers return value
    self = [super init];
    if (!self) return(nil);
	
	[[CGameManager sharedGameManager] SetScaleFactors];
	
	CCLOG(@"XScale:%.1f YScale:%.1f IphoneOffset:%.1f",
		  XSCALEFACTOR,
		  YSCALEFACTOR,
		  IPHONEOFFSET);
	
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	_middleY = screenSize.height / 2;
	
	CCSprite *bgSprite = [CCSprite spriteWithImageNamed:@"MainBG.png"];
	bgSprite.positionType = CCPositionTypeNormalized;
	bgSprite.position = ccp(0.5,0.5);
	bgSprite.scaleX = XSCALEFACTOR;
	[self addChild:bgSprite z:kZindexBG];
	
	CCSprite *floorSprite = [CCSprite spriteWithImageNamed:@"Floor.png"];
	floorSprite.positionType = CCPositionTypeNormalized;
	floorSprite.position = ccp(0.5,0.0);
	floorSprite.anchorPoint = ccp(0.5, 0.0);
	floorSprite.scaleX = XSCALEFACTOR;
	[self addChild:floorSprite z:kZindexFloor];
	_floorY = floorSprite.boundingBox.size.height / 2;
	
	_robin = [CRobin spriteWithImageNamed:@"Robin.png"];
	_robin.positionType = CCPositionTypePoints;
	_robin.position = ccp(kRobinStartX * screenSize.width, 0.5 * screenSize.height);
	[self addChild:_robin z:kZindexRobin];
	[_robin Initialise:screenSize.height];
	[_robin Reset];
	
	CCLOG(@"Robin Box:%@ Position:%@",NSStringFromCGRect( [_robin boundingBox]),
		  NSStringFromCGPoint(_robin.position));
	_gameTime = 0.0;
	_gameStarted = NO;
	
	self.userInteractionEnabled = YES;
	_flyingObjects = [[NSMutableArray alloc] init];
	_tubeObjects = [[NSMutableArray alloc] init];
	_lastGetUnderY = 0;
	[self AddAllClouds];
	
	_gameScore = 0;
	const float ScoreFontSize = 24 * YSCALEFACTOR;
	const float ScorePositionX = 12 * YSCALEFACTOR;
	const float ScorePositionY = 6 * YSCALEFACTOR;
	
	_scoreLabel = [[CCLabelTTF alloc] initWithString:@"Score: 0" fontName:@"Marker Felt" fontSize:ScoreFontSize];
	[_scoreLabel setAnchorPoint:ccp(0,1)];
	[_scoreLabel setPosition:ccp(ScorePositionX, screenSize.height - ScorePositionY)];
	[_scoreLabel setColorRGBA:[CCColor colorWithRed:1.0 green:0.0 blue:0.0]];
	[self addChild:_scoreLabel z:kZindexRobin];
	
	_highScoreLabel = [[CCLabelTTF alloc] initWithString:@"HighScore: 0" fontName:@"Marker Felt" fontSize:ScoreFontSize];
	[_highScoreLabel setAnchorPoint:ccp(0,1)];
	[_highScoreLabel setPosition:ccp(ScorePositionX, _scoreLabel.boundingBox.origin.y - ScorePositionY)];
	[_highScoreLabel setColorRGBA:[CCColor colorWithRed:1.0 green:0.0 blue:0.0]];
	[self addChild:_highScoreLabel z:kZindexRobin];
	[self UpdateHighScoreLabel];

	_gameOverLabel = [[CCLabelTTF alloc] initWithString:@"Game Over!"
											   fontName:@"Marker Felt"
											   fontSize:ScoreFontSize];
	[_gameOverLabel setPosition:ccp(screenSize.width/2, screenSize.height/2)];
	[_gameOverLabel setColorRGBA:[CCColor colorWithRed:1.0 green:0.0 blue:0.0]];
	[self addChild:_gameOverLabel z:kZindexRobin];
	[_gameOverLabel setVisible:NO];
	
	_PressToStartLabel = [[CCLabelTTF alloc] initWithString:@"Tap Screen To Start"
											   fontName:@"Marker Felt"
											   fontSize:ScoreFontSize];
	[_PressToStartLabel setPosition:ccp(screenSize.width/2, screenSize.height*2/3)];
	[_PressToStartLabel setColorRGBA:[CCColor colorWithRed:1.0 green:0.0 blue:0.0]];
	[self addChild:_PressToStartLabel z:kZindexRobin];

	
	[[CGameManager sharedGameManager] PlayBGMusic];
	
    // done
	return self;
}

-(void)UpdateScoreLabel {
	[_scoreLabel setString:[NSString stringWithFormat:@"Score: %d",_gameScore]];
}

-(void)UpdateHighScoreLabel {
	CGameManager *man = [CGameManager sharedGameManager];
	
	if(_gameScore > [man GetHighScore]) {
		[man SetHighScore:_gameScore];
	}
	[_highScoreLabel setString:[NSString stringWithFormat:@"HighScore: %d",[man GetHighScore]]];
}

-(void)update:(CCTime)delta {
	_gameTime += delta;
	
	BOOL gameOver = NO;
	
	if(_gameStarted == YES) {
		
		_lastSpawnTime += delta;
		[self UpdateScoreLabel];
		if(_lastSpawnTime > _nextSpawnTime) {
			[self SetSpawnTime];
			[self SpawnNewTubes];
		}
		
		[_robin UpdateRobin:delta];
		if(_robin.position.y  < _floorY) {
			gameOver = YES;
		} else {
			for (CTube *tube in _tubeObjects) {
				if(CGRectIntersectsRect([_robin TubeCollisionBox], tube.boundingBox)) {
					CCLOG(@"Tube Collision");
					gameOver = YES;
					break;
				} else if(tube.Scored == false && tube.State == kTubeStateActive) {
					if(tube.boundingBox.origin.x + tube.boundingBox.size.width <
					   _robin.boundingBox.origin.x) {
						tube.Scored = true;
						_gameScore += kTubeScore;
						[[CGameManager sharedGameManager] PlayEffect:kEffectScore];
					}
				}
			}
		}
	}
	
	if(gameOver == YES) {
		[[CGameManager sharedGameManager] PlayEffect:kEffectExplode];
		[self GameOver];
	}
	
}

-(void)GameOver {
	_gameStarted = NO;
	self.userInteractionEnabled = NO;
	[_gameOverLabel setVisible:YES];
	[_robin Reset];
	[self StopGame];
	CCActionDelay *delayAction = [CCActionDelay actionWithDuration:2.0f];
	CCActionCallFunc *actionCallReenable = [CCActionCallFunc
											actionWithTarget:self
											selector:@selector(ReenableAfterGameOver)];
	[self runAction:[CCActionSequence
					 actionWithArray:@[delayAction, actionCallReenable]]];
}

-(void)ReenableAfterGameOver {
	[_gameOverLabel setVisible:NO];
	[_PressToStartLabel setVisible:YES];
	[self UpdateHighScoreLabel];
	
	_gameScore = 0;
	[self UpdateScoreLabel];
	
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	_robin.position = ccp(kRobinStartX * screenSize.width, 0.5 * screenSize.height);
	
	for (CTube *tube in _tubeObjects) {
		[tube Stop];
	}
	
	self.userInteractionEnabled = YES;
}

-(void)touchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
	CGPoint touchLocation = [touch locationInNode:self];
	//CCLOG(@"touchLocation:%@",NSStringFromCGPoint(touchLocation));

	if(_robin.State == kRobinStateStopped) {
		_robin.State = kRobinStateMoving;
		_gameStarted = YES;
		[self StartGame];
		[[CGameManager sharedGameManager] PlayEffect:kEffectTap];
	}
	
	if(_gameStarted == YES) {
		[_robin SetStartSpeed];
		[[CGameManager sharedGameManager] PlayEffect:kEffectTap];
	}
	
}

-(void)StartGame {
	[_PressToStartLabel setVisible:NO];
	_lastTubeType = kTubeTypeNone;
	_lastGetUnderY = _middleY;
	_nextSpawnTime = 0.2;
	
	for (CCloud *cloud in _flyingObjects) {
		[cloud Start];
	}
	
	/*for (CTube *tube in _tubeObjects) {
		[tube Stop];
	}*/
}

-(void)StopGame {
	for (CCloud *cloud in _flyingObjects) {
		[cloud Stop];
	}
	
	for (CTube *tube in _tubeObjects) {
		[tube stopAllActions];
	}
}


-(CGPoint)scaledPosition:(CGPoint)pos {
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	return ccp(pos.x * (screenSize.width / 480), pos.y * (screenSize.height / 320));
}

-(void)AddCloudWithName:(NSString*)name andPositon:(CGPoint)pos andZindex:(int)zindex andScale:(float)scale andSpeed:(float)speed {
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	CCloud *cloud = [CCloud spriteWithImageNamed:name];
	[cloud setScale:scale];
	[cloud setPosition:[self scaledPosition:pos]];
	[cloud InitialiseWithSpeed:speed andWidth:screenSize.width];
	[self addChild:cloud z:zindex];
	[_flyingObjects addObject:cloud];
}

-(void)AddAllClouds {
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(350, 305) andZindex:kZindexCloudSlow andScale:kCloudScaleSlow andSpeed:kCloudSpeedSlow];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(75, 290) andZindex:kZindexCloudSlow andScale:kCloudScaleSlow andSpeed:kCloudSpeedSlow];
	
	
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(75, 150) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(200, 250) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(440, 200) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	
	
	[self AddCloudWithName:@"Mount.png" andPositon:ccp(150, 85) andZindex:kZindexMount andScale:kMountScale andSpeed:kCloudSpeedMount];
	[self AddCloudWithName:@"Mount.png" andPositon:ccp(440, 85) andZindex:kZindexMount andScale:kMountScale andSpeed:kCloudSpeedMount];
	
	
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(64, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(312, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(420, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
}

-(void)SetSpawnTime {
	_lastSpawnTime = 0;
	_nextSpawnTime = ( (float)(rand() % kTubeSpawnTimeVariance) ) / 10 + kTubeSpawnMinTime;
}

-(void)SpawnNewTubes {
	int ourChance = rand() % 3 + 1;
	
	while(1) {
		if(_lastTubeType == kTubeTypeUpper && ourChance == 1) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypeLower && ourChance == 2) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypePair && ourChance == 3) {
			ourChance = rand() % 3 + 1;
		} else {
			break;
		}
	}
	
	if(ourChance == 1) {
		[self SpawnUpperOrLower:YES];
	} else if(ourChance == 2) {
		[self SpawnUpperOrLower:NO];
	} else {
		[self SpawnTubePair];
	}
}

-(void)SpawnUpperOrLower:(bool)isUpper {
	_lastTubeType = isUpper == true ? kTubeTypeUpper : kTubeTypeLower;
	
	int Ymax = isUpper == true ? _middleY : kSingleGapTop;
	int Ymin = isUpper == true ? kSingleGapBottom : _middleY;
	
	if(isUpper == false) {
		if(Ymax - _lastGetUnderY > kTubeMaxUpPixels) {
			Ymax = kTubeMaxUpPixels;
		}
	}
	
	int YRange = abs(Ymax - Ymin);
	int Ypos = Ymax - rand() % YRange;
	
	if(isUpper == true) {
		_lastGetUnderY = Ypos;
	} else {
		_lastGetUnderY = _middleY;
	}
	
	[self SpawnNewTube:isUpper atYpos:Ypos];
}

-(void)SpawnTubePair {
	_lastTubeType = kTubeTypePair;
	
	int Gap = kDoubleGapMin + (rand() % (int)(kDoubleGapMax - kDoubleGapMin));
	int YRange = kDoubleGapTop - Gap - kDoubleGapBottom;
	int TopY = kDoubleGapTop - (rand() % YRange);
	int BottomY = TopY - Gap;
	
	_lastGetUnderY = TopY;
	
	[self SpawnNewTube:YES atYpos:TopY];
	[self SpawnNewTube:NO atYpos:BottomY];
}

-(void)SpawnNewTube:(bool)isUpper atYpos:(float)Ypos {
	CTube *nextTube = [self GetNextTube];
	if(isUpper == true) {
		[nextTube setAnchorPoint:ccp(0.5, 0)];
		[nextTube setFlipY:NO];
	} else {
		[nextTube setAnchorPoint:ccp(0.5, 1)];
		[nextTube setFlipY:YES];
	}
	
	[nextTube setPosition:ccp(nextTube.position.x, Ypos)];
	[nextTube Start];
}

-(CTube*)GetNextTube {
	for(CTube *tube in _tubeObjects) {
		if(tube.State == kTubeStateInActive) {
			return tube;
		}
	}
	
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	CTube *newTube = [CTube spriteWithImageNamed:@"Tube.png"];
	[newTube InitialiseWithSpeed:kCloudSpeedTree andWidth:screenSize.width];
	[self addChild:newTube z:kZindexTube];
	[_tubeObjects addObject:newTube];
	return newTube;
}





















@end













