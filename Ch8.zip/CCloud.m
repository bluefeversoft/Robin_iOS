//
//  CCloud.m
//  Simple Flappy Robin
//
//  Created by ScreenCast on 28/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CCloud.h"

@implementation CCloud

-(void)Start{
	[self stopAllActions];
	
	float CurrentX = self.position.x;
	float distance = CurrentX - ( - self.XOffSet);
	float time = distance / self.Speed;
	CGPoint destination = ccp(-self.XOffSet, self.position.y);
	
	CCActionMoveTo *actionMove = [CCActionMoveTo actionWithDuration:time position:destination];
	CCActionCallFunc *actionMoveDone = [CCActionCallFunc actionWithTarget:self selector:@selector(ReachedDestination)];
	[self runAction:[CCActionSequence actionWithArray:@[actionMove, actionMoveDone]]];
}

-(void)Stop{
	[self stopAllActions];
}

-(void)ReachedDestination{
	[self setPosition:ccp(self.ScreenWidth + self.XOffSet, self.position.y)];
	[self Start];
}

-(void)InitialiseWithSpeed:(float)speed andWidth:(float)wth {
	self.Speed = speed;
	self.ScreenWidth = wth;
	self.XOffSet = self.boundingBox.size.width;
}







@end
