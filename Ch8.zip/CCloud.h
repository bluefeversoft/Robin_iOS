//
//  CCloud.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 28/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "cocos2d.h"

@interface CCloud : CCSprite

@property (nonatomic) float Speed;
@property (nonatomic) float XOffSet;
@property (nonatomic) float ScreenWidth;

-(void)Start;
-(void)Stop;
-(void)ReachedDestination;
-(void)InitialiseWithSpeed:(float)speed andWidth:(float)wth;

@end
