//
//  Constants.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 09/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#ifndef Simple_Flappy_Robin_Constants_h
#define Simple_Flappy_Robin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40

#define YSCALEFACTOR ([CGameManager sharedGameManager].YScaleFactor)
#define XSCALEFACTOR ([CGameManager sharedGameManager].XScaleFactor)
#define IPHONEOFFSET ([CGameManager sharedGameManager].iPhoneFivePointOffSet)

#define GRAVITY -310 * YSCALEFACTOR

#define kZindexRobin 100

#endif
