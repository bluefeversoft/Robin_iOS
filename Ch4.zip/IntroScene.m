//
//  IntroScene.m
//  BaseStarter
//
//  Created by ScreenCast on 09/04/14.
//  Copyright BlueFever 2014. All rights reserved.
//
// -----------------------------------------------------------------------

// Import the interfaces
#import "IntroScene.h"
#import "Constants.h"
#import "CGameManager.h"

// -----------------------------------------------------------------------
#pragma mark - IntroScene
// -----------------------------------------------------------------------

@implementation IntroScene

// -----------------------------------------------------------------------
#pragma mark - Create & Destroy
// -----------------------------------------------------------------------

+ (IntroScene *)scene
{
	return [[self alloc] init];
}

// -----------------------------------------------------------------------

- (id)init
{
    // Apple recommend assigning self with supers return value
    self = [super init];
    if (!self) return(nil);
	
	[[CGameManager sharedGameManager] SetScaleFactors];
	
	CCLOG(@"XScale:%.1f YScale:%.1f IphoneOffset:%.1f",
		  XSCALEFACTOR,
		  YSCALEFACTOR,
		  IPHONEOFFSET);

	CCSprite *bgSprite = [CCSprite spriteWithImageNamed:@"MainBG.png"];
	bgSprite.positionType = CCPositionTypeNormalized;
	bgSprite.position = ccp(0.5,0.5);
	bgSprite.scaleX = XSCALEFACTOR;
	[self addChild:bgSprite z:kZindexBG];
	
	CCSprite *floorSprite = [CCSprite spriteWithImageNamed:@"Floor.png"];
	floorSprite.positionType = CCPositionTypeNormalized;
	floorSprite.position = ccp(0.5,0.0);
	floorSprite.anchorPoint = ccp(0.5, 0.0);
	floorSprite.scaleX = XSCALEFACTOR;
	[self addChild:floorSprite z:kZindexFloor];
	
    // done
	return self;
}

@end













