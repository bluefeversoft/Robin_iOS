//
//  Constants.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 09/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#ifndef Simple_Flappy_Robin_Constants_h
#define Simple_Flappy_Robin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40
#define kZindexTree 50
#define kZindexMount 30
#define kZindexCloudSlow 10
#define kZindexCloudFast 20

#define YSCALEFACTOR ([CGameManager sharedGameManager].YScaleFactor)
#define XSCALEFACTOR ([CGameManager sharedGameManager].XScaleFactor)
#define IPHONEOFFSET ([CGameManager sharedGameManager].iPhoneFivePointOffSet)

#define GRAVITY -310 * YSCALEFACTOR

#define kZindexRobin 100
#define kRobinStateStopped 0
#define kRobinStateMoving 1
#define kRobinStartSpeed 150 * YSCALEFACTOR
#define kRobinStartX 0.3

#define kCloudSpeedSlow 7.0 * YSCALEFACTOR
#define kCloudSpeedFast 25.0 * YSCALEFACTOR
#define kCloudSpeedMount 15.0 * YSCALEFACTOR
#define kCloudSpeedTree 30.0 * YSCALEFACTOR

#define kCloudScaleSlow 0.4
#define kCloudScaleFast 0.8
#define kTreeScale 1.0
#define kMountScale 0.8

#define kTubeStateActive 0
#define kTubeStateInActive 1

#define kTubeSpawnMinTime 2.3
#define kTubeSpawnTimeVariance 8

#define kSingleGapTop 440 * YSCALEFACTOR
#define kSingleGapBottom 230 * YSCALEFACTOR
#define kSingleGapMax 280 * YSCALEFACTOR
#define kSingleGapMin 160 * YSCALEFACTOR

#define kDoubleGapTop 480 * YSCALEFACTOR
#define kDoubleGapBottom 120 * YSCALEFACTOR
#define kDoubleGapMax 220 * YSCALEFACTOR
#define kDoubleGapMin 140 * YSCALEFACTOR


#endif




















