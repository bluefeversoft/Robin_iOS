//
//  IntroScene.m
//  BaseStarter
//
//  Created by ScreenCast on 09/04/14.
//  Copyright BlueFever 2014. All rights reserved.
//
// -----------------------------------------------------------------------

// Import the interfaces
#import "IntroScene.h"
#import "Constants.h"
#import "CGameManager.h"
#import "CRobin.h"
#import "CCloud.h"
#import "CTube.h"

// -----------------------------------------------------------------------
#pragma mark - IntroScene
// -----------------------------------------------------------------------

@implementation IntroScene {
	CRobin *_robin;
	float _floorY;
	BOOL _gameStarted;
	float _gameTime;
	NSMutableArray *_flyingObjects;
	NSMutableArray *_tubeObjects;
	float _nextSpawnTime;
	float _lastSpawnTime;
	int _lastTubeType;
}

// -----------------------------------------------------------------------
#pragma mark - Create & Destroy
// -----------------------------------------------------------------------

+ (IntroScene *)scene
{
	return [[self alloc] init];
}

// -----------------------------------------------------------------------

- (id)init
{
    // Apple recommend assigning self with supers return value
    self = [super init];
    if (!self) return(nil);
	
	[[CGameManager sharedGameManager] SetScaleFactors];
	
	CCLOG(@"XScale:%.1f YScale:%.1f IphoneOffset:%.1f",
		  XSCALEFACTOR,
		  YSCALEFACTOR,
		  IPHONEOFFSET);
	
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];

	CCSprite *bgSprite = [CCSprite spriteWithImageNamed:@"MainBG.png"];
	bgSprite.positionType = CCPositionTypeNormalized;
	bgSprite.position = ccp(0.5,0.5);
	bgSprite.scaleX = XSCALEFACTOR;
	[self addChild:bgSprite z:kZindexBG];
	
	CCSprite *floorSprite = [CCSprite spriteWithImageNamed:@"Floor.png"];
	floorSprite.positionType = CCPositionTypeNormalized;
	floorSprite.position = ccp(0.5,0.0);
	floorSprite.anchorPoint = ccp(0.5, 0.0);
	floorSprite.scaleX = XSCALEFACTOR;
	[self addChild:floorSprite z:kZindexFloor];
	_floorY = floorSprite.boundingBox.size.height / 2;
	
	_robin = [CRobin spriteWithImageNamed:@"Robin.png"];
	_robin.positionType = CCPositionTypePoints;
	_robin.position = ccp(kRobinStartX * screenSize.width, 0.5 * screenSize.height);
	[self addChild:_robin z:kZindexRobin];
	[_robin Initialise:screenSize.height];
	[_robin Reset];
	
	CCLOG(@"Robin Box:%@ Position:%@",NSStringFromCGRect( [_robin boundingBox]),
		  NSStringFromCGPoint(_robin.position));
	_gameTime = 0.0;
	_gameStarted = NO;
	
	self.userInteractionEnabled = YES;
	_flyingObjects = [[NSMutableArray alloc] init];
	_tubeObjects = [[NSMutableArray alloc] init];

	[self AddAllClouds];
	
    // done
	return self;
}

-(void)update:(CCTime)delta {
	_gameTime += delta;
	
	BOOL gameOver = NO;
	
	if(_gameStarted == YES) {
		[_robin UpdateRobin:delta];
		if(_robin.position.y  < _floorY) {
			gameOver = YES;
		}
	}
	
	if(gameOver == YES) {
		CGSize screenSize = [[CCDirector sharedDirector] viewSize];
		_robin.position = ccp(kRobinStartX * screenSize.width, 0.5 * screenSize.height);
		[_robin Reset];
		_gameStarted = NO;
		[self StopGame];
	}
	
}

-(void)touchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
	CGPoint touchLocation = [touch locationInNode:self];
	CCLOG(@"touchLocation:%@",NSStringFromCGPoint(touchLocation));
	
	if(_robin.State == kRobinStateStopped) {
		_robin.State = kRobinStateMoving;
		_gameStarted = YES;
		[self StartGame];
	}
	
	if(_gameStarted == YES) {
		[_robin SetStartSpeed];
	}
	
}

-(void)StartGame {
	for (CCloud *cloud in _flyingObjects) {
		[cloud Start];
	}
}

-(void)StopGame {
	for (CCloud *cloud in _flyingObjects) {
		[cloud Stop];
	}
}


-(CGPoint)scaledPosition:(CGPoint)pos {
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	return ccp(pos.x * (screenSize.width / 480), pos.y * (screenSize.height / 320));
}

-(void)AddCloudWithName:(NSString*)name andPositon:(CGPoint)pos andZindex:(int)zindex andScale:(float)scale andSpeed:(float)speed {
	CGSize screenSize = [[CCDirector sharedDirector] viewSize];
	CCloud *cloud = [CCloud spriteWithImageNamed:name];
	[cloud setScale:scale];
	[cloud setPosition:[self scaledPosition:pos]];
	[cloud InitialiseWithSpeed:speed andWidth:screenSize.width];
	[self addChild:cloud z:zindex];
	[_flyingObjects addObject:cloud];
}

-(void)AddAllClouds {
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(350, 305) andZindex:kZindexCloudSlow andScale:kCloudScaleSlow andSpeed:kCloudSpeedSlow];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(75, 290) andZindex:kZindexCloudSlow andScale:kCloudScaleSlow andSpeed:kCloudSpeedSlow];
	
	
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(75, 150) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(200, 250) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	[self AddCloudWithName:@"Cloud.png" andPositon:ccp(440, 200) andZindex:kZindexCloudFast andScale:kCloudScaleFast andSpeed:kCloudSpeedFast];
	
	
	[self AddCloudWithName:@"Mount.png" andPositon:ccp(150, 85) andZindex:kZindexMount andScale:kMountScale andSpeed:kCloudSpeedMount];
	[self AddCloudWithName:@"Mount.png" andPositon:ccp(440, 85) andZindex:kZindexMount andScale:kMountScale andSpeed:kCloudSpeedMount];
	
	
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(64, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(312, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
	[self AddCloudWithName:@"Tree.png" andPositon:ccp(420, 36) andZindex:kZindexTree andScale:kTreeScale andSpeed:kCloudSpeedTree];
}

-(void)SetSpawnTime {
	
}

-(void)SpawnNewTubes {
	
}

-(void)SpawnUpperOrLower:(bool)isUpper {
	
}

-(void)SpawnTubePair {
	
}

-(void)SpawnNewTube:(bool)isUpper atYpos:(float)Ypos {
	
}

-(CTube*)GetNextTube {
	return nil;
}





















@end













