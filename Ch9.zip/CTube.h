//
//  CTube.h
//  Simple Flappy Robin
//
//  Created by ScreenCast on 09/05/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CCloud.h"

@interface CTube : CCloud

@property (nonatomic) float InactiveX;
@property (nonatomic) int State;
@property (nonatomic) bool Scored;

@end
