//
//  CTube.m
//  Simple Flappy Robin
//
//  Created by ScreenCast on 09/05/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CTube.h"
#import "Constants.h"

@implementation CTube

-(void)Start{
	[self stopAllActions];
	
	float distance = self.XOffSet * 2 + self.ScreenWidth;
	float time = distance / self.Speed;
	CGPoint destination = ccp(-self.XOffSet, self.position.y);
	[self setPosition:ccp(self.XOffSet + self.ScreenWidth, self.position.y)];
	
	CCActionMoveTo *actionMove = [CCActionMoveTo actionWithDuration:time position:destination];
	CCActionCallFunc *actionMoveDone = [CCActionCallFunc actionWithTarget:self selector:@selector(ReachedDestination)];
	self.State = kTubeStateActive;
	[self setVisible:YES];
	[self runAction:[CCActionSequence actionWithArray:@[actionMove, actionMoveDone]]];
}

-(void)Stop {
	[self stopAllActions];
	[self setVisible:NO];
	self.State = kTubeStateInActive;
	[self setPosition:ccp(self.InactiveX, self.position.y)];
	self.Scored = false;
}

-(void)ReachedDestination{
	[self Stop];
}

-(void)InitialiseWithSpeed:(float)speed andWidth:(float)wth {
	self.Speed = speed;
	self.ScreenWidth = wth;
	self.XOffSet = self.boundingBox.size.width;
	self.InactiveX = -self.ScreenWidth;
}










@end
