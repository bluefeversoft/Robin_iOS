//
//  CRobin.m
//  Simple Flappy Robin
//
//  Created by ScreenCast on 11/04/14.
//  Copyright (c) 2014 BlueFever. All rights reserved.
//

#import "CRobin.h"
#import "Constants.h"
#import "CGameManager.h"

@implementation CRobin


-(void)Reset {
	self.State = kRobinStateStopped;
	[self SetStartSpeed];
}

-(void)SetStartSpeed {
	_speedY = kRobinStartSpeed;
}

-(void)Initialise:(float)tos {
	_topOfScreen = tos;
}

-(void)UpdateRobin:(float)dt {
	
}


@end
